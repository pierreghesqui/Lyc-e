import keyboard #permet d'utiliser la fonction keyboard.is_presdsed('ctrl')

t = keyboard.is_pressed('ctrl') #t = True si 'CTRL'est enfoncé
                                #t = False sinon
print (t)