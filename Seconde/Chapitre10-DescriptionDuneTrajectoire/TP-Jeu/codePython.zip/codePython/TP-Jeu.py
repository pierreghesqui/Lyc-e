from fonctions.fonctionPotion import vecteurDeplacement, trajectoireDuChat #Chargement des fonctions

M0M1 = vecteurDeplacement(0,300)

trajectoireDuChat([M0M1]) #Ajouter des vecteurs déplacement pour compléter la trajectoire du chat

